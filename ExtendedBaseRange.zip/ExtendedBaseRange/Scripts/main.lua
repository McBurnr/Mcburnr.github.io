----------------- ↓↓  -- Change this to Your Custom Size. ---------------------------------------------------------------------

local BaseRange = 150                                                                                         -- Default Size 70

----------------------------- DO NOT EDIT ANYTHING BELOW HERE IF YOU DONT KNOW WHAT YOU ARE DOING -----------------------------

    local function VisualAreaRange(PalObject)
        local paths = {
            "/Game/Pal/Blueprint/MapObject/BuildObject/BP_BuildObject_PalBoxV2.BP_BuildObject_PalBoxV2_C:AreaRange_GEN_VARIABLE",
            "/Game/Pal/Blueprint/MapObject/BuildObject/BP_BuildObject_PalBoxV2.BP_BuildObject_PalBoxV2_C:AreaRange1_GEN_VARIABLE"
        }
        for _, objPath in ipairs(paths) do
            local obj = StaticFindObject(objPath)
            if obj and obj:IsValid() then
                obj.RelativeScale3D = { X = BaseRange, Y = BaseRange, Z = BaseRange }
            end
        end
        if PalObject and PalObject:IsValid() then
            ExecuteWithDelay(1, function()
                if PalObject.AreaRange and type(PalObject.AreaRange) ~= "number" then return end
                PalObject.AreaRange = BaseRange * (3500 / 70)
            end)
        end
    end

    for _, objectPath in ipairs({
        "/Script/Pal.PalBaseCampModel",
        "/Script/Pal.PalBuildObjectBaseCampPoint"
    }) do
        NotifyOnNewObject(objectPath, VisualAreaRange)
    end

    local function SpawnRange()
        local calculatedDistance = BaseRange * (4000 / 70)
        local extraWorkAreaRange = BaseRange * (70000 / 70)

        local invadeMinRadius = BaseRange * (5000 / 70) 					-- Untested
        local invadeMaxRadius = BaseRange * (15000 / 70) 					-- Untested

        local neighborMinDistance = (BaseRange ^ 1.23) * (1500 / 70) 				-- Remove the following line to enable base overlap
        local combatRange = BaseRange * (2000 / 70) 

        for _, game_settings in ipairs(FindAllOf("PalGameSetting") or {}) do
            if game_settings:IsValid() then
                if type(game_settings.SpawnerDisableDistanceCM_FromBaseCamp) == "number" then
                    game_settings.SpawnerDisableDistanceCM_FromBaseCamp = calculatedDistance
                end
                if type(game_settings.BaseCampExtraWorkAreaRange) == "number" then
                    game_settings.BaseCampExtraWorkAreaRange = extraWorkAreaRange
                end
                if type(game_settings.InvadeStartPoint_BaseCampRadius_Min_cm) == "number" then
                    game_settings.InvadeStartPoint_BaseCampRadius_Min_cm = invadeMinRadius
                end
                if type(game_settings.InvadeStartPoint_BaseCampRadius_Max_cm) == "number" then
                    game_settings.InvadeStartPoint_BaseCampRadius_Max_cm = invadeMaxRadius
                end
                if type(game_settings.BaseCampNeighborMinimumDistance) == "number" then
                    game_settings.BaseCampNeighborMinimumDistance = neighborMinDistance
                end
                if type(game_settings.BaseCampPalCombatRange_AddCampRange) == "number" then
                    game_settings.BaseCampPalCombatRange_AddCampRange = combatRange
                end
            end
        end
    end

    RegisterHook("/Script/Engine.PlayerController:ClientRestart", SpawnRange)
    RegisterHook("/Script/Engine.PlayerController:ServerAcknowledgePossession", SpawnRange)

-------------------------------------------------------------------------------------------------------------------------------
